INSERT INTO ecommerce_system.`main_feature_info` VALUES 
(1,'2025-04-14 22:57:07.000000',0,_binary '\0','ACCOUNT_MANAGEMENT','account management'),
(2,'2025-04-14 23:27:07.000000',0,_binary '\0','PRODUCT_MANAGEMENT','product management'),
(3,'2025-02-04 22:57:07.000000',0,_binary '\0','ORDER_MANAGEMENT','order management');
