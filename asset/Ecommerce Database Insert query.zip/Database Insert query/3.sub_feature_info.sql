INSERT INTO ecommerce_system.`sub_feature_info` VALUES 
(1,'2025-02-04 22:57:46.000000',0,_binary '\0',1,'ADMIN_BASIC','admin basic'),
(2,'2025-02-04 22:57:46.000000',0,_binary '\0',1,'USER_BASIC','user basic'),
(3,'2025-02-04 22:57:46.000000',0,_binary '\0',2,'PRODUCT_BASIC','product basic'),
(4,'2025-02-04 22:57:46.000000',0,_binary '\0',3,'ORDER_BASIC','order basic');
